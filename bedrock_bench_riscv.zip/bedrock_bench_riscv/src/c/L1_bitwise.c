/* L1_bitwise — Expected: 0xB0A5 (45221) */
#define MAILBOX 0x3FC8F000u

void _start(void) {
    unsigned x = 42405u;
    x = x ^ 65280u;
    x = x & 255u;
    x = x | 45056u;
    *(volatile unsigned *)MAILBOX = x;
    for (;;) { }
}
