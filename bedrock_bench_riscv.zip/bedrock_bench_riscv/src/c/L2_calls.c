/* L2_calls — Expected: 23 */
#define MAILBOX 0x3FC8F000u

static unsigned add2(unsigned a, unsigned b) {
    return a + b;
}

static unsigned scale(unsigned x) {
    unsigned y = x * 2u;
    y = y + 9u;
    return y;
}

void _start(void) {
    unsigned z = add2(3u, 4u);
    z = scale(z);
    *(volatile unsigned *)MAILBOX = z;
    for (;;) { }
}
