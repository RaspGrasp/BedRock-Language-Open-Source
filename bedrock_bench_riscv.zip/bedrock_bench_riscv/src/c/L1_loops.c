/* L1_loops — Expected: 10000 */
#define MAILBOX 0x3FC8F000u

void _start(void) {
    unsigned a = 0;
    unsigned i = 0;
    while (i < 100u) {
        unsigned j = 0;
        while (j < 100u) {
            a = a + 1u;
            j = j + 1u;
        }
        i = i + 1u;
    }
    *(volatile unsigned *)MAILBOX = a;
    for (;;) { }
}
