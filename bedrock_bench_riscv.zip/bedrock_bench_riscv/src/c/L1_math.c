/* L1_math — same algorithm as L1_math.br
 * freestanding-style entry for size-fair builds
 * Expected at MAILBOX: 5005
 */
#define MAILBOX 0x3FC8F000u

void _start(void) {
    unsigned n = 100;
    unsigned s = 0;
    unsigned i = 1;
    while (i <= n) {
        s = s + i;
        i = i + 1;
    }
    unsigned t = s * 2u;
    t = t / 2u;
    t = t - 45u;
    *(volatile unsigned *)MAILBOX = t;
    for (;;) { }
}
