/* L2_fib — F(25) = 75025 */
#define MAILBOX 0x3FC8F000u

void _start(void) {
    unsigned n = 25;
    unsigned a = 0;
    unsigned b = 1;
    unsigned i = 0;
    unsigned t = 0;
    while (i < n) {
        t = a + b;
        a = b;
        b = t;
        i = i + 1;
    }
    *(volatile unsigned *)MAILBOX = a;
    for (;;) { }
}
