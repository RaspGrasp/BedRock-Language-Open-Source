#!/usr/bin/env bash
# Optional: verify BedRock binaries on your RV32 emulator.
# Usage:
#   ./scripts/run_emu_check.sh /path/to/rv32_emu.py
#   ./scripts/run_emu_check.sh /path/to/rv32_emu.py --max 5000000

set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
EMU="${1:?path to rv32_emu.py}"
shift || true

BINS=(
  L1_math_br.bin
  L1_loops_br.bin
  L1_bitwise_br.bin
  L2_fib_br.bin
  L2_calls_br.bin
)

echo "Expected mailbox values:"
echo "  L1_math=5005  L1_loops=10000  L1_bitwise=45221 (0xB0A5)"
echo "  L2_fib=75025  L2_calls=23"
echo

for b in "${BINS[@]}"; do
  path="$ROOT/build/$b"
  if [[ ! -f "$path" ]]; then
    echo "MISSING $path — run: python3 scripts/run_bench.py first"
    continue
  fi
  echo "========== $b =========="
  python3 "$EMU" "$path" "$@"
  echo
done
