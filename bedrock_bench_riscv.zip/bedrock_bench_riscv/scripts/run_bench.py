#!/usr/bin/env python3
"""
BedRock vs C (RISC-V) benchmark harness — compile time + binary size.

Usage (from repo root bedrock_bench_riscv/):
  python3 scripts/run_bench.py
  python3 scripts/run_bench.py --runs 30
  python3 scripts/run_bench.py --skip-c          # BedRock only
  python3 scripts/run_bench.py --bedrockco /path/to/bedrockco

Outputs:
  results/bench_results.csv
  results/bench_results.md
"""

from __future__ import annotations

import argparse
import csv
import os
import shutil
import statistics
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BR_DIR = ROOT / "src" / "br"
C_DIR = ROOT / "src" / "c"
OUT = ROOT / "build"
RES = ROOT / "results"

BENCHMARKS = [
    "L1_math",
    "L1_loops",
    "L1_bitwise",
    "L2_fib",
    "L2_calls",
]

EXPECTED = {
    "L1_math": 5005,
    "L1_loops": 10000,
    "L1_bitwise": 0xB0A5,
    "L2_fib": 75025,
    "L2_calls": 23,
}


def which(name: str) -> str | None:
    return shutil.which(name)


def run_timed(cmd: list[str], runs: int, warmup: int = 5) -> dict:
    """Time `cmd` `runs` times after `warmup` untimed warm-up runs.

    Returns a dict with mean/median/std/min/max (ms), the raw samples,
    whether all runs succeeded, and a `noisy` flag that fires when the
    relative standard deviation (std/mean) exceeds 50% — a sign the
    measurement was contaminated by cold caches or background load
    rather than reflecting real compiler performance.
    """
    ok = True

    # Warm-up: let the OS page cache / filesystem / CPU frequency scaling
    # settle before any timed run. Discarded, never counted in stats.
    for _ in range(warmup):
        p = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if p.returncode != 0:
            ok = False
            break

    times: list[float] = []
    if ok:
        for _ in range(runs):
            t0 = time.perf_counter()
            p = subprocess.run(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
                text=True,
            )
            t1 = time.perf_counter()
            if p.returncode != 0:
                ok = False
                err = (p.stderr or "")[:300]
                print(f"  FAIL cmd={' '.join(cmd)}\n  {err}", file=sys.stderr)
                break
            times.append((t1 - t0) * 1000.0)

    if not times:
        return {
            "mean": 0.0, "median": 0.0, "std": 0.0,
            "min": 0.0, "max": 0.0, "samples": [], "ok": False, "noisy": False,
        }

    mean = statistics.mean(times)
    median = statistics.median(times)
    std = statistics.stdev(times) if len(times) > 1 else 0.0
    noisy = mean > 0 and (std / mean) > 0.5  # relative std > 50% = contaminated measurement
    return {
        "mean": mean, "median": median, "std": std,
        "min": min(times), "max": max(times),
        "samples": times, "ok": ok, "noisy": noisy,
    }


def filesize(path: Path) -> int:
    return path.stat().st_size if path.is_file() else -1


def compile_bedrock(bedrockco: str, name: str, runs: int, warmup: int) -> dict:
    src = BR_DIR / f"{name}.br"
    out = OUT / f"{name}_br.bin"
    OUT.mkdir(parents=True, exist_ok=True)
    cmd = [bedrockco, str(src), "--target", "riscv", "-o", str(out)]
    stats = run_timed(cmd, runs, warmup)
    ok = stats["ok"]
    return {
        "name": name,
        "side": "BedRock",
        "compile_mean_ms": round(stats["mean"], 3) if ok else "",
        "compile_median_ms": round(stats["median"], 3) if ok else "",
        "compile_std_ms": round(stats["std"], 3) if ok else "",
        "compile_min_ms": round(stats["min"], 3) if ok else "",
        "compile_max_ms": round(stats["max"], 3) if ok else "",
        "noisy": stats["noisy"],
        "size_bytes": filesize(out) if ok else "",
        "size_bytes_raw_objcopy_do_not_compare": "",
        "ok": ok,
        "artifact": str(out) if ok else "",
    }


def compile_c(gcc: str, name: str, runs: int, warmup: int) -> dict:
    src = C_DIR / f"{name}.c"
    elf = OUT / f"{name}_c.elf"
    binpath = OUT / f"{name}_c.bin"
    OUT.mkdir(parents=True, exist_ok=True)

    # Freestanding RV32 — adjust march if your toolchain differs
    base_cmd = [
        gcc,
        "-march=rv32imc",
        "-mabi=ilp32",
        "-Os",
        "-ffreestanding",
        "-nostdlib",
        "-Wl,-e,_start",
        "-o",
        str(elf),
        str(src),
    ]

    stats = run_timed(base_cmd, runs, warmup)
    ok = stats["ok"]
    size = -1
    raw_size = ""
    if ok and elf.is_file():
        # Canonical size = the linked ELF. A raw `objcopy -O binary` dump is
        # NOT used for the headline comparison: without a full linker script
        # it strips sections it shouldn't and reports a few bytes for a
        # multi-hundred-byte program (see README §1, item 4) — that was the
        # bug in the original run. We still produce it, but only as an
        # explicitly-labeled, do-not-compare reference column.
        size = filesize(elf)
        objcopy = which("riscv32-esp-elf-objcopy") or which("riscv32-unknown-elf-objcopy")
        if objcopy:
            subprocess.run(
                [objcopy, "-O", "binary", str(elf), str(binpath)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            raw_size = filesize(binpath) if binpath.is_file() else ""

    return {
        "name": name,
        "side": "C_GCC",
        "compile_mean_ms": round(stats["mean"], 3) if ok else "",
        "compile_median_ms": round(stats["median"], 3) if ok else "",
        "compile_std_ms": round(stats["std"], 3) if ok else "",
        "compile_min_ms": round(stats["min"], 3) if ok else "",
        "compile_max_ms": round(stats["max"], 3) if ok else "",
        "size_bytes_raw_objcopy_do_not_compare": raw_size,
        "noisy": stats["noisy"],
        "size_bytes": size if ok else "",
        "ok": ok,
        "artifact": str(binpath if binpath.is_file() else elf) if ok else "",
    }


def try_emu(emu: str, binpath: Path, expected: int) -> str:
    if not emu or not binpath.is_file():
        return "skip"
    # Best-effort: many emulators print mailbox; we only check exit 0
    p = subprocess.run(
        [sys.executable, emu, str(binpath)],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=60,
    )
    text = p.stdout or ""
    if str(expected) in text or hex(expected) in text.lower():
        return "pass_hint"
    if p.returncode == 0:
        return "ran"
    return "fail"


def write_outputs(rows: list[dict], warmup: int) -> None:
    RES.mkdir(parents=True, exist_ok=True)
    csv_path = RES / "bench_results.csv"
    md_path = RES / "bench_results.md"

    fields = [
        "name",
        "side",
        "compile_mean_ms",
        "compile_median_ms",
        "compile_std_ms",
        "compile_min_ms",
        "compile_max_ms",
        "noisy",
        "size_bytes",
        "size_bytes_raw_objcopy_do_not_compare",
        "ok",
        "artifact",
    ]
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in fields})

    lines = [
        "# BedRock vs C (RISC-V) — compile time & size",
        "",
        "| Benchmark | Side | Mean (ms) | Median (ms) | Std (ms) | Min (ms) | Max (ms) | Size (bytes) | OK | Noisy? |",
        "|-----------|------|-----------|--------------|----------|----------|----------|---------------|----|--------|",
    ]
    any_noisy = False
    for r in rows:
        flag = "⚠ YES" if r.get("noisy") else ""
        if r.get("noisy"):
            any_noisy = True
        lines.append(
            f"| {r['name']} | {r['side']} | {r['compile_mean_ms']} | {r['compile_median_ms']} | "
            f"{r['compile_std_ms']} | {r['compile_min_ms']} | {r['compile_max_ms']} | "
            f"{r['size_bytes']} | {r['ok']} | {flag} |"
        )
    raw_rows = [r for r in rows if r.get("side") == "C_GCC" and r.get("size_bytes_raw_objcopy_do_not_compare") != ""]
    lines += [
        "",
        "## Methodology notes",
        "",
        f"- Each target ran {warmup} untimed warm-up compiles before the timed runs, "
        "so cold-cache/first-run effects don't contaminate the statistics.",
        "- BedRock: `bedrockco <file.br> --target riscv`",
        "- C: `riscv32-*-gcc -march=rv32imc -mabi=ilp32 -Os -ffreestanding -nostdlib -Wl,-e,_start`",
        "- **Size (the 'Size (bytes)' column above): BedRock raw `.bin` vs C's linked ELF file "
        "size.** This is the fair, citable comparison — both numbers represent a complete, "
        "loadable image for that toolchain.",
        "- Runtime comparison: use `scripts/run_emu_check.sh` with your `rv32_emu.py`",
        "- Expected mailbox values: see README.md",
        "- 'Noisy?' flags any row where std/mean > 50% — the measurement is likely "
        "contaminated by system jitter (background processes, CPU frequency scaling) "
        "and the median, not the mean, should be quoted/trusted for that row.",
        "",
    ]
    if raw_rows:
        lines += [
            "## Reference only — NOT a fair size comparison, do not quote",
            "",
            "`objcopy -O binary` strips the ELF down to raw loadable bytes without a real "
            "linker script, which drops sections it shouldn't and produces numbers far "
            "below any real executable's size. Kept here only to show the artifact exists, "
            "never as a BedRock-vs-GCC size claim:",
            "",
            "| Benchmark | C raw objcopy size (bytes) |",
            "|-----------|------------------------------|",
        ]
        for r in raw_rows:
            lines.append(f"| {r['name']} | {r['size_bytes_raw_objcopy_do_not_compare']} |")
        lines.append("")
    if any_noisy:
        lines.append(
            "> **At least one row was flagged noisy.** Close other applications, "
            "re-run, and prefer the median for any flagged benchmark before quoting "
            "it in the poster or paper.\n"
        )
    md_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"Wrote {csv_path}")
    print(f"Wrote {md_path}")
    if any_noisy:
        print("\n⚠ WARNING: one or more benchmarks had std/mean > 50% (noisy measurement).")
        print("  Re-run after closing background apps, or trust the median column instead of the mean.")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", type=int, default=30, help="timed compiles per target")
    ap.add_argument("--warmup", type=int, default=5,
                     help="untimed warm-up compiles before the timed runs (default 5)")
    ap.add_argument("--bedrockco", default=os.environ.get("BEDROCKCO", "bedrockco"))
    ap.add_argument("--gcc", default=os.environ.get("RISCV_GCC", ""))
    ap.add_argument("--skip-c", action="store_true")
    ap.add_argument("--emu", default="", help="path to rv32_emu.py (optional check)")
    args = ap.parse_args()

    br = args.bedrockco if Path(args.bedrockco).is_file() else which(args.bedrockco)
    if not br:
        print("ERROR: bedrockco not found. Pass --bedrockco /path/to/bedrockco", file=sys.stderr)
        return 1

    gcc = args.gcc
    if not gcc:
        for cand in (
            "riscv32-esp-elf-gcc",
            "riscv32-unknown-elf-gcc",
            "riscv32-none-elf-gcc",
        ):
            gcc = which(cand) or ""
            if gcc:
                break

    print(f"bedrockco = {br}")
    print(f"gcc       = {gcc or '(none — C side skipped)'}")
    print(f"runs      = {args.runs}  (+ {args.warmup} warm-up runs, discarded)")
    print()

    rows: list[dict] = []
    for name in BENCHMARKS:
        print(f"=== {name} / BedRock ===")
        rows.append(compile_bedrock(br, name, args.runs, args.warmup))
        if not args.skip_c and gcc:
            print(f"=== {name} / C ===")
            rows.append(compile_c(gcc, name, args.runs, args.warmup))
        elif not args.skip_c and not gcc:
            print(f"=== {name} / C skipped (no riscv gcc) ===")

    write_outputs(rows, args.warmup)

    if args.emu:
        print("\nEmu smoke (best-effort):")
        for name in BENCHMARKS:
            bp = OUT / f"{name}_br.bin"
            status = try_emu(args.emu, bp, EXPECTED[name])
            print(f"  {name}: {status}")

    print("\nDone. Send results/bench_results.csv and any emu logs back for recording.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
